package com.mario.otpbusdatacapture;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class MainActivity extends AppCompatActivity {

    private FusedLocationProviderClient client;


    Calendar calendar;
    String currentDate;
    String currentTime;
    String studentID;
    String processedData;
    double currentLatitude;
    double currentLongitude;
    TextView latitude;
    TextView longitude;
    TextView date;
    TextView time;
    TextView id;
    TextView scanCapture;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        permissionRequest();

        latitude = findViewById(R.id.Latitude);
        longitude = findViewById(R.id.Longitude);
        date = findViewById(R.id.Date);
        time = findViewById(R.id.Time);
        id = findViewById(R.id.id);
        scanCapture = findViewById(R.id.swipeCapture);

        client = LocationServices.getFusedLocationProviderClient(this);

    }
    public void idUpdate()
    {
        studentID = scanCapture.getText() + "";
        id.setText(studentID);
        scanCapture.setText("");
    }
    public void dateUpdate()
    {
        calendar = Calendar.getInstance();
        currentDate = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());
        date.setText(currentDate);
    }
    public void timeUpdate()
    {
        calendar = Calendar.getInstance();
        @SuppressLint("SimpleDateFormat") SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
        currentTime = format.format(calendar.getTime());
        time.setText(currentTime);
    }
    public void locationUpdate()
    {
        if (ActivityCompat.checkSelfPermission(MainActivity.this, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            return;
        client.getLastLocation().addOnSuccessListener(MainActivity.this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location)
            {
                if(location != null)
                {
                    currentLatitude = location.getLatitude();
                    currentLongitude = location.getLongitude();
                    latitude.setText(currentLatitude + "");
                    longitude.setText(currentLongitude + "");
                }
            }
        });
    }
    public void dataUpdate(View view)
    {
            idUpdate();
            dateUpdate();
            timeUpdate();
            locationUpdate();
            dataCapture();
    }
    private void permissionRequest()
    {
        ActivityCompat.requestPermissions(this,new String[]{ACCESS_FINE_LOCATION},1);
        ActivityCompat.requestPermissions(this,new String[]{WRITE_EXTERNAL_STORAGE},1);
    }
    public void dataCapture()
    {
        if (ActivityCompat.checkSelfPermission(MainActivity.this, WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            return;
        processedData = studentID + "," + currentLatitude + "," + currentLongitude + "," + currentTime + "," + currentDate + "\n";
        File dataFile = new File(Environment.getExternalStorageDirectory(),"OTPBusData.txt");
        try {
            FileOutputStream output = new FileOutputStream(dataFile,true);
            output.write(processedData.getBytes());
            output.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
